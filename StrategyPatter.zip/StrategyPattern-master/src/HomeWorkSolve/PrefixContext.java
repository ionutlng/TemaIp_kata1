package HomeWorkSolve;

import java.util.HashMap;


public class PrefixContext {
    private HashMap<Country,IPhoneStrategy> prefix = new HashMap<>();

    public PrefixContext()
    {
        prefix.put(Country.BELGIUM,new BelgiumPrefix());
        prefix.put(Country.ENGLAND,new EnglandPrefix());
        prefix.put(Country.NEDERLANDS,new NetherlandPrefix());
        prefix.put(Country.FRANCE,new FrancePrefix());
    }

    public String doExecute(Country country)
    {
        return prefix.get(country).Phone();
    }

}
