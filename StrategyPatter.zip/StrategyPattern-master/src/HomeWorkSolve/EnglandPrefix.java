package HomeWorkSolve;


public class EnglandPrefix implements IPhoneStrategy {
    String phone;

    EnglandPrefix()
    {
        phone = "+41 ";
    }


    @Override
    public String Phone() {
        return phone;
    }
}
