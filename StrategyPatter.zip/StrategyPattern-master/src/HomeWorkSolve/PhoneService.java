package HomeWorkSolve;


public class PhoneService {

    public String phone(Country country)
    {
        PrefixContext context = new PrefixContext();
        return context.doExecute(country);
    }
}
