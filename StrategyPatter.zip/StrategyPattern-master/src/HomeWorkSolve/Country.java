package HomeWorkSolve;


public enum Country {
    BELGIUM,
    NEDERLANDS,
    FRANCE,
    ENGLAND
}
