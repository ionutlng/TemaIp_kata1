package HomeWorkSolve;


public interface IPhoneStrategy {
    public String Phone();
}
