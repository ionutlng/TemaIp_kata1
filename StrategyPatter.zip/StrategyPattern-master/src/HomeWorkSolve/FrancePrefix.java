package HomeWorkSolve;


public class FrancePrefix implements IPhoneStrategy {
    String phone;
    FrancePrefix()
    {
        phone = "+31 ";
    }

    @Override
    public String Phone() {
        return phone;
    }
}
