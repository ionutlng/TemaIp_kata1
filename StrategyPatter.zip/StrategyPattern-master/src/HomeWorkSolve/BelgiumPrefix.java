package HomeWorkSolve;

public class BelgiumPrefix implements  IPhoneStrategy {

    String prefix ;

    BelgiumPrefix()
    {
        prefix  = "+32 ";
    }
    @Override
    public String Phone() {
        return prefix;
    }
}
