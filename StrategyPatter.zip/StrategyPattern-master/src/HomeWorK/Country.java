package HomeWorK;

public enum Country{
	BELGIUM,
	NEDERLANDS,
	FRANCE,
	ENGLAND
}