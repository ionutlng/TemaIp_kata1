package HomeWorkSolve;

/**
 * Created by Vasile Catana on 3/27/2017.
 */
public enum Country {
    BELGIUM,
    NEDERLANDS,
    FRANCE,
    ENGLAND
}
